<style>
    .appointments-table {
        width: 100%;
        border-collapse: collapse;
    }

    .appointments-table th, .appointments-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ccc;
    }

    .appointments-table th {
        background-color: #f0f0f0;
        font-weight: bold;
    }
</style>
<h1>Appointments</h1>

    <table class="appointments-table">
        <thead>
            <tr>
                <th>id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Appointment</th>
                <th>Subject</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($appointment->id); ?></td>
                    <td><?php echo e($appointment->name); ?></td>
                    <td><?php echo e($appointment->email); ?></td>
                    <td><?php echo e($appointment->phone); ?></td>
                    <td><?php echo e($appointment->appointment); ?></td>
                    <td><?php echo e($appointment->subject); ?></td>
                    <td><?php echo e($appointment->message); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php /**PATH C:\Users\EYUB\Desktop\SurfLandingPage\resources\views/admin.blade.php ENDPATH**/ ?>